/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author MarwahAlaofi
 */
public class Student {
    
    //data fields
    private String name;
    private String id;
    private double gpa;
    private int level;

    // argument constructor
    public Student(String name, String id, double gpa, int level) {
        this.name = name;
        this.id = id;
        this.gpa = gpa;
        this.level = level;
    }

    //getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testing;


/**
 *
 * @author MarwahAlaofi
 */
public class CourseTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        
       //Create Student array 
        Student[] students=new Student[3];
       
        //create an object for each student in the array
       students[0]=new Student("Sara","123145",4.5,4);
       students[1]=new Student("Sahar","123412",3.5,2);
       students[2]=new Student("Amnah","133345",3.75,4);
     
       
       // create a professor object using the argument constructor
        Professor prof=new Professor("Nora",12);
        
        //create a course object and set its data fields using setters
        Course course=new Course();
        course.setStudentsList(students);
        course.setProfessor(prof);
        course.setName("Programmming II");
        course.setCode("CS112");
        
        
        System.out.println("Course Name: "+course.getName());
        System.out.println("Course Code: "+course.getCode());
        System.out.println("Course Professor: "+course.getProfessor().getName());
        
        System.out.println("List of students: ");
        
        for(Student student:course.getStudentsList())
        {
             System.out.println(" - Name: "+student.getName()+", ID: "+student.getId()+", level: "+student.getLevel()+", GPA: "+student.getGpa());
        }
        
        System.out.println("*********************************************");      
        
    }
    
}
